const deals = [
  {
    id: 1,
    price: 1400,
    menuItems: ['A', 'B', 'C'],
  },
  {
    id: 2,
    price: 1800,
    menuItems: ['D', 'E', 'F'],
  },
];
export default deals;
